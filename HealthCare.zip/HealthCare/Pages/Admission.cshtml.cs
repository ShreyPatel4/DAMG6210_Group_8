using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Configuration;
using System;
using System.Data;
using System.Data.SqlClient;

namespace HealthCare.Pages.Admission
{
    public class IndexModel : PageModel
    {
        private readonly IConfiguration _configuration;

        public IndexModel(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        public IActionResult OnGet()
        {
            return Page();
        }

        public IActionResult OnPostInsertAdmission()
        {
            // Call the stored procedure to insert admission
            try
            {
                InsertAdmissionFromTreatment();
                TempData["SuccessMessage"] = "Admission successfully inserted.";
            }
            catch (Exception ex)
            {
                TempData["ErrorMessage"] = "Error: " + ex.Message;
            }

            return RedirectToPage("/Admission");
        }

        private void InsertAdmissionFromTreatment()
        {
            string connectionString = _configuration.GetConnectionString("HealthCareDatabase");

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    using (SqlCommand command = new SqlCommand("InsertAdmissionFromTreatment", connection))
                    {
                        command.CommandType = CommandType.StoredProcedure;

                        command.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Error inserting admission: " + ex.Message);
            }
        }
    }
}
