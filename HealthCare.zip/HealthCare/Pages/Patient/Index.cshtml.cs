using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Data.SqlClient;
using System.Net;
using System.Reflection;
using System.Runtime.Intrinsics.X86;

namespace HealthCare.Pages.Patient
{
    public class IndexModel : PageModel
    {
        public List<PatientData> patientList=new List<PatientData>();
        public void OnGet()
        {
            try
            {
                String connectionString = "Data Source=DESKTOP-QOQD6ET;Initial Catalog=HealthCareManagementSystem;Integrated Security=True;Encrypt=False";
                using(SqlConnection connection = new SqlConnection(connectionString)) 
                {
                    connection.Open();
                    String query = "Select * from Patient";
                    using (SqlCommand command = new SqlCommand( query, connection))
                    {
                        using(SqlDataReader reader = command.ExecuteReader()) 
                        { 
                            while(reader.Read())
                            {
                                PatientData p = new PatientData();
                                p.PatientID = reader.GetString(0);
                                p.SSN = reader.GetString(1);
                                p.FirstName = reader.GetString(2);
                                p.LastName = reader.GetString(3);
                                p.DateOfBirth = reader.GetDateTime(4).ToString();
                                p.Gender = reader.GetString(5);
                                p.Email = reader.GetString(6);
                                p.Address = reader.GetString(7);
                                p.PhoneNumber = reader.GetString(8);
                                p.EmergencyContact = reader.GetString(9);
                                p.BloodType = reader.GetString(10);
                                patientList.Add(p);
                               
                            }
                        }
                    }
                
                
                }
                
            }
            catch(Exception ex)
            {

                Console.WriteLine("Exception is :" + ex.ToString());
            }
            
        }
    }
    public class PatientData
    {
        public string PatientID;
        public string SSN;
        public string FirstName;
        public string LastName         ;
        public string DateOfBirth      ;
        public string Gender           ;
        public string Email            ;
        public string Address          ;
        public string PhoneNumber      ;
        public string EmergencyContact ;
        public string BloodType        ;
    }

}
